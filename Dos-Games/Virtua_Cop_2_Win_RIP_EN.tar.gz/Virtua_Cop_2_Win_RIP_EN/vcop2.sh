#!/bin/bash
cd "/home/mikl/.wine/drive_c/Games/Virtua_Cop_2_Win_RIP_EN/Game Files/"
wine "ppj2dd.exe"
